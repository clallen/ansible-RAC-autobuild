#!/bin/bash

HOME=/opt/apps/fast

FASTSEARCH=$HOME/esp
export FASTSEARCH

ESP4J_HOME=$FASTSEARCH/esp4j
export ESP4J_HOME

PATH=$PATH:$HOME/bin:$FASTSEARCH/bin
export PATH

LIBPATH=$ESP4J_HOME/dist:$FASTSEARCH/lib
export LIBPATH

SHLIB_PATH=$LIBPATH
export SHLIB_PATH

LD_LIBRARY_PATH=$LIBPATH
export LD_LIBRARY_PATH

OMNIORB_CONFIG=$FASTSEARCH/etc/omniorb.cfg
export OMNIORB_CONFIG

LM_LICENSE_FILE=$FASTSEARCH/etc/fastsearch.lic
export LM_LICENSE_FILE

JAVA_HOME=$FASTSEARCH/_jvm
export JAVA_HOME

NAMESERVER_CONFIG=$FASTSEARCH/etc/nameservice.cfg
export NAMESERVER_CONFIG

PYTHONPATH=$FASTSEARCH/lib/python2.3
export PYTHONPATH

PYTHONHOME=$FASTSEARCH/lib/python2.3
export PYTHONHOME

# getting a count of statuses from nctrl sysstatus
return=`/opt/apps/fast/esp/bin/nctrl sysstatus | grep -A 50 '\-\-\-' | grep -v "\-\-" | grep -v "^$" | sort $NF | awk '{print $(NF-1)" "$NF}' | sed 's/[0-9]*//g' |  uniq -c | echo \`awk '{for(i=2;i<NF;++i)printf"%s ",$i;print $(NF)" "$1";"}'\``
echo $return;

# counting number of words in $return.  Anything more than 2 is a problem.
if [ `echo $return | sed 's/Running//g' | wc -w` -gt 1 ]
then
	exit 1
else
	exit 0
fi
