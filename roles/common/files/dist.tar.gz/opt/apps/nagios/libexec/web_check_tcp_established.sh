#!/bin/bash
#
# $Id: //IT/WebSystems/Scripts/nagios/web_check_tcp_established.sh#3 $
# $DateTime: 2010/05/13 16:42:50 $
#
# Checks the number of Established TCP Connections on a Given Port
# 
#
# Works on Linux only - adding support for Solaris is certainly doable, but
# we don't have any Solaris OAS hosts.
#

#
#  Matt White | National Instruments | May 13, 2010
#


# Set a really shallow PATH
PATH=/bin:/usr/bin


usage()
{
cat << EOF
usage: $0 <options>

This script checks to see if the number of established TCP connections on
a given port is within a given threshold.

OPTIONS:
 -p   TCP port number to check (eg. 80)      [REQUIRED]
 -w   Warn if above this value (eg. 50)      [REQUIRED]
 -c   Critical is above this value (eg. 100) [REQUIRED]
 -?   Display this message
 -V   Display version

Example:
  $0 -p 80 -w 50 -c 100

EOF
}


# Process the command line options
PORT_NUMBER=
WARNING_COUNT=
CRITICAL_COUNT=
while getopts "p:c:w:V?" OPTION
do
     case $OPTION in
         p)
             PORT_NUMBER=$OPTARG
             ;;
         c)
             CRITICAL_COUNT=$OPTARG
             ;;
         w)
             WARNING_COUNT=$OPTARG
             ;;
         V)
             echo "Version 0.1"
             exit 1
             ;;
         ?)
             usage
             exit 1
             ;;
     esac
done

if [[ -z $PORT_NUMBER ]] || [[ -z $CRITICAL_COUNT ]] || [[ -w $WARNING_COUNT ]]
then
     usage
     exit 1
fi


# Make sure that critical > warning.
if [ "$WARNING_COUNT" -ge "$CRITICAL_COUNT" ]; then
     echo "Warning count ($WARNING_COUNT) is higher than critical count ($CRITICAL_COUNT)!"
     exit 3
fi


# Run netstat to get the information requested
COUNT=`netstat -nt|grep ESTAB|awk '{print $4}'|grep ":$PORT_NUMBER"|wc -l`


if [ "$COUNT" -ge "$CRITICAL_COUNT" ]; then
     echo "$COUNT established connection(s) on port tcp/$PORT_NUMBER"!
     exit 2
fi

if [ "$COUNT" -ge "$WARNING_COUNT" ]; then
     echo "$COUNT established connection(s) on port tcp/$PORT_NUMBER"!
     exit 1
fi


# If we make it this far, everything is fine...
echo "$COUNT connection(s) established on port tcp/$PORT_NUMBER. | $COUNT"
exit 0

