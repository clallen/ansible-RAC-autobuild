#!/bin/sh

echo "Checking disk labels."
for i in {10..98}; do
    echo "Processing disk c1d${i}...\c"

    # Check for a label on the disk
    if ( `prtvtoc /dev/rdsk/c1d${i}s2 > /dev/null 2>&1` ); then
        echo "label found."
    else
        echo "no label found."
        echo "Adding label to c1d${i}...\c"

        # Label disk if one does not exist
        format -L vtoc -d c1d${i} > /dev/null 2>&1

        if [ $? -eq 0 ]; then
            echo "done."
        else
            echo "failed."
            echo "ERROR: Label failed on c1d${i}"
            ERR=1
        fi
    fi

    # Check for whole disk partion table
    if [ `prtvtoc /dev/rdsk/c1d${i}s2 | grep -v ^* | wc -l` -eq 2 ]; then		
        echo "Good partition table found on disk c1d${i}"
    else
        # Create whole disk slice 0 partition table starting at cylinder 1
        echo "Adding whole disk partition table...\c"
        prtvtoc /dev/rdsk/c1d${i}s2 | gawk -f ./fmthard.awk \
        | fmthard -s - /dev/rdsk/c1d${i}s2

        if [ $? -eq 0 ]; then
            echo "done."
        else
            echo "failed."
            echo "ERROR: Label failed on c1d${i}"
            ERR=1
        fi
    fi

    # Set the ownership and permissions for RAC.
    chown grid:dba /dev/rdsk/c1d${i}s0
    chmod 660 /dev/rdsk/c1d${i}s0
done
