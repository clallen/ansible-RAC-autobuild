#!/bin/sh

if [ $# -ne 1 ]; then
        echo "Usage: `basename $0` <hostname>"
        exit 1
fi

HOST=$1
HOST_IP=`host $HOST | awk '$3~/address/ {print $4}'`
P_HOST_IP=`host ${HOST}-priv1 | awk '$3~/address/ {print $4}'`
#P_HOST_IP1=`host ${HOST}-priv1 | awk '$3~/address/ {print $4}'`
#P_HOST_IP2=`host ${HOST}-priv2 | awk '$3~/address/ {print $4}'`

case $HOST_IP in
    130.164.13.*)
        GATEWAY=130.164.13.1
        CIDR=24
        ;;
    130.164.51.*)
        NET=`echo $HOST_IP | awk -F. '{print $4}'`
        if [ $NET -lt 64 ]; then
            GATEWAY=130.164.51.1
            CIDR=26
        elif [[ $NET -gt 65 && $NET -lt 128 ]]; then
            GATEWAY=130.164.51.65
            CIDR=26
        elif [[ $NET -gt 129 && $NET -lt 160 ]]; then
            GATEWAY=130.164.51.129
            CIDR=27
        elif [[ $NET -gt 161 && $NET -lt 192 ]]; then
            GATEWAY=130.164.51.161
            CIDR=27
        elif [ $NET -gt 193 ]; then
            GATEWAY=130.164.51.193
            CIDR=27
        fi
        ;;
    *)
        echo "ERROR: Invalid network detected - $HOST_IP is not in a known range"
        exit
        ;;
esac

case $HOST in
    *1)
        OHOST=`echo $HOST | tr 1 2`
        ;;
    *2)
        OHOST=`echo $HOST | tr 2 1`
        ;;
esac

P_OHOST_IP=`host ${OHOST}-priv1 | awk '$3~/address/ {print $4}'`
#P_OHOST_IP1=`host ${OHOST}-priv1 | awk '$3~/address/ {print $4}'`
#P_OHOST_IP2=`host ${OHOST}-priv2 | awk '$3~/address/ {print $4}'`

./chhn $HOST

dladm rename-link net1 publink0
dladm rename-link net2 publink1
dladm rename-link net3 privlink0
dladm rename-link net4 privlink1

ipadm create-ip publink0
ipadm create-ip publink1
ipadm create-ip privlink0
ipadm create-ip privlink1

echo "Building IPMP interfaces...\c"

ipadm create-ipmp -i publink0,publink1 pubnet0
sleep 5

ipadm create-ipmp -i privlink0,privlink1 privnet0

sleep 5
echo "done"

ipadm create-addr -T static -a local=$HOST_IP/${CIDR} pubnet0
ipadm create-addr -T static -a local=$P_HOST_IP/24 privnet0

cat << EOF >> /etc/hosts
#
${HOST_IP}  ${HOST}.natinst.com $HOST
${P_HOST_IP}   ${HOST}-priv1
${P_OHOST_IP}  ${OHOST}-priv1
EOF

route -p add default $GATEWAY

if [ "$(ping $GATEWAY 1)" ]; then
        echo "Deleting mgmt default route"
        route -p delete default 130.164.28.1
else
        echo "Error: Possible problem with public network...can not ping gateway"
        echo "Error: Keeping existing default route in place"
fi

svccfg -s ipmp setprop config/transitive-probing = boolean: true
svcadm restart ipmp


#echo ""
#echo "Network configuration completed"
#echo "Link status:"
#dladm show-link
#echo ""
#echo "IP Addresses:"
#ipadm show-addr
#echo ""
#echo "Routes:"
#netstat -rn
