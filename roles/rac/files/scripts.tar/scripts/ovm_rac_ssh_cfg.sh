#!/bin/sh

if [ $# -ne 1 ]; then
        echo "Usage: `basename $0` <username>"
        exit 1
fi

USER=$1

HOST=`hostname | awk -F\. '{print $1}'`
R_HOST=${HOST%?}

echo "Processing $USER SSH keys:"

echo "Checking for existing keys...\c"
if [ -f /home/$USER/.ssh/id_dsa ]; then
	echo "$USER keys exist.\n"
else
	echo "generating...\c"
	su - $USER -c "ssh-keygen -t dsa -f /home/$USER/.ssh/id_dsa -N ''" > /dev/null
	echo "done.\n"
fi

case $HOST in
        *1)
            echo "Checking authorized_keys file...\c"
            
            if [ -f /home/$USER/.ssh/authorized_keys ]; then
                echo "file exists."
            else
                cat /home/$USER/.ssh/id_dsa.pub > /home/$USER/.ssh/authorized_keys
                echo "file created."
            fi
            
            echo "Checking for other hosts key...\c"
            if [ "$(grep $USER@${R_HOST}2 /home/$USER/.ssh/authorized_keys)" ]; then
                echo "key found.\n"
            else
                echo "key not found.\n"
                echo "Paste other hosts key now:\n"
                read KEY
                echo $KEY >> /home/$USER/.ssh/authorized_keys
                echo "Key added to authorized_keys file.\n"
            fi
            
            echo "Press <Enter> after authorized_keys file has been added to the other host."
            read JUNK
            
            echo "Checking SSH between hosts:"
            echo "\t$HOST -> $HOST...\c"
            su - $USER -c "ssh -q -o BatchMode=yes -o StrictHostKeyChecking=no $USER@$HOST echo 2>&1" > /dev/null && echo "successful" || echo "failed"
            echo "\t$HOST -> ${R_HOST}2...\c"
            su - $USER -c "ssh -q -o BatchMode=yes -o StrictHostKeyChecking=no $USER@${R_HOST}2 echo 2>&1" > /dev/null && echo "successful" || echo "failed"
            ;;
        
        *)
            echo "$HOST public key:"
            cat /home/$USER/.ssh/id_dsa.pub
            echo ""
            
            echo "Checking authorized_keys file...\c"
            
            if [ -f /home/$USER/.ssh/authorized_keys ]; then
                echo "file exists."
            else
                echo "file does not exists."
                echo "Press <Enter> after this hosts key has been added to the authorized_keys file on ${R_HOST}1."
                read JUNK
                echo "Retrieving authorized_keys file from ${R_HOST}1."
                su - $USER -c "scp -o StrictHostKeyChecking=no $USER@${R_HOST}1:/home/$USER/.ssh/authorized_keys /home/$USER/.ssh/authorized_keys" > /dev/null 2>&1
            fi
            
            echo "Checking SSH between hosts:"
            echo "\t$HOST -> $HOST...\c"
            su - $USER -c "ssh -q -o BatchMode=yes -o StrictHostKeyChecking=no $USER@$HOST echo 2>&1" > /dev/null && echo "successful" || echo "failed"
            echo "\t$HOST -> ${R_HOST}1...\c"
            su - $USER -c "ssh -q -o BatchMode=yes -o StrictHostKeyChecking=no $USER@${R_HOST}1 echo 2>&1" > /dev/null && echo "successful" || echo "failed"
            ;;
esac


