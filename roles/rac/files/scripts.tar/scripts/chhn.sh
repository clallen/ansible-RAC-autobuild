#!/bin/ksh

case $# in
    1)
        old=`hostname | sed -e 's/\..*//'`
        new=$1
        ;;

    2)
        old=$1
        new=$2
        ;;

    *)
        echo "ERROR: $0 <new name> - Old name is determined from the OS"
        echo "ERROR: $0 <old name> <new name>"
        ;;
esac

PATH=/bin:/usr/bin:/sbin:/usr/sbin

[ -z "$new" ] && { echo "ERROR: $0 <new hostname>" ; exit 1 ; }
[ -z "$old" ] && { echo "ERROR: Unable to determine old hostname: $old" ; exit 1 ; }

function update {
# $1 - File to update
    
    [ -z "$1" ] && { echo "ERROR: Not enough arguments" ; exit 1 ; }
    echo $1 | egrep "rename$" > /dev/null
    [ $? -eq 0 ] && return
    
    echo "Updating $1 ..."
    
    [ ! -f "$1" ] && { echo "WARNING: $1 doesn't exist" ; return 0 ; }
    
    cp $1 $1.rename
    if [ $? -ne 0 ] ; then
        echo "ERROR: Backup copy failed" 
        exit 1
    fi
    
    sed -e "s/$old/$new/g" $1.rename > $1
    if [ $? -ne 0 ] ; then
        echo "ERROR: Update of $1 failed."
    fi
}

function solaris_update {
    case `uname -r` in
        5.11)
            echo "Updating hostname..."
            svccfg -s identity:node setprop config/nodename = astring: $HOST
            if [ $? -ne 0 ] ; then
                echo "ERROR: Update of hostname failed."
            fi
            svcadm refresh identity:node
#            update /root/.rhosts
            ;;
        *)
#            update /etc/net/ticlts/hosts
#            update /etc/net/ticots/hosts
#            update /etc/net/ticotsord/hosts
#            update /etc/nodename
#            update /.rhosts
#
#            for hn in /etc/hostname.* ; do
#        	update $hn
#            done
    
            [ `/usr/bin/uname -r` -eq '5.6' ] && exit 0
            echo "Updating DumpAdm..."
            rm -f /etc/dumpadm.conf
            dumpadm -s /var/crash/$new
            ;;
    esac

#    update /etc/inet/hosts
    update /etc/passwd
    /usr/sbin/pwconv

    for horcm in /etc/horcm*.conf ; do
        update $horcm
    done

}

function linux_update {
    update /etc/hosts
    update /etc/sysconfig/network
    update /etc/passwd
    update /etc/sysconfig/rhn/systemid
    update /root/.rhosts
}

case `uname -s` in
    Linux)
	[ ! -f /etc/redhat-release ] && { echo "ERROR: Only RedHat is supported" ; exit 1 ; }
	linux_update
	;;

    SunOS)
	solaris_update
	;;

    *)
	echo "ERROR: Unsupported system type"
	exit 1
	;;
esac
hostname $new
