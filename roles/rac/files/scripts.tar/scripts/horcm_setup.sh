#!/bin/sh

[ -z "$1" ] &&
{
	echo 'Usage: horcm_setup.sh [5|6]'
	exit
}

HORCMINST="horcm$1"

if pkg info horcm > /dev/null 2>&1 ; then 
	echo HORCM is installed
else
	echo Installing HORCM
	pkg install horcm
	echo Installing HORCM completed
fi

if svcs $HORCMINST > /dev/null 2>&1; then
	echo $HORCMINST is configured
else
	echo Configuring $HORCMINST
	svccfg -s site/horcm add $HORCMINST
	svccfg -s site/horcm:$HORCMINST addpg general framework
	svccfg -s site/horcm:$HORCMINST addpropvalue general/enabled boolean: false
        rsync -va /opt/local/scripts/production/ovm/files/$HORCMINST.conf /etc/$HORCMINST.conf
        svcadm enable $HORCMINST
fi

if svcs $HORCMINST > /dev/null 2>&1; then
#        echo "\nDevices seen on this host\n"
#        ls /dev/rdsk* | /HORCM/usr/bin/inqraid -fnx -CLI | gawk 'BEGIN {print "HORCM_LDEV"; print "#dev_group\tdev_name\tSerial#\tCU:LDEV(LDEV#)\tMU#"} $9~/DATA|FRA/ {str=$9;search="_";split(str,array,search);cu=substr($4,0,2);ldev=substr($4,3);print tolower(array[1]"_"array[2])"\t"tolower($9)"\t93133\t"cu":"ldev"\t\t0"} $9~/DATA_01/ {str=$9;search="_";split(str,array,search);data=array[1]"_"array[2]} $9~/FRA_01/ {str=$9;search="_";split(str,array,search);fra=array[1]"_"array[2]} END {print "HORCM_INST";print "#dev_group\tip_address\tservice"; print tolower(data)"\tboxmgr\t\t$HORCMINST"; print tolower(fra)"\tboxmgr\t\t$HORCMINST"}'
        echo "Building /etc/$HORCMINST.conf file\n"
        ls /dev/rdsk* | /HORCM/usr/bin/inqraid -fnx -CLI | gawk -v host=`hostname` -f ./$HORCMINST.awk > /etc/$HORCMINST.conf
fi
